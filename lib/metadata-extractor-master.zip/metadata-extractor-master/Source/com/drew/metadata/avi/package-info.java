/**
 * Contains classes for the extraction and modelling of AVI file metadata.
 */
package com.drew.metadata.avi;
