/**
 * Contains classes for the extraction and modelling of EPS metadata.
 */
package com.drew.metadata.eps;
