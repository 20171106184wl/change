/**
 * Contains {@link com.drew.metadata.Directory} and {@link com.drew.metadata.TagDescriptor} classes related to the
 * modelling of manufacturer-specific makernotes.
 */
package com.drew.metadata.exif.makernotes;
