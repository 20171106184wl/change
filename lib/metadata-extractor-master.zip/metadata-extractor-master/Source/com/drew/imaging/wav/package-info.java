/**
 * Contains classes for working with WAV files.
 */
package com.drew.imaging.wav;
