/**
 * Contains classes for working with TIFF format files.
 */
package com.drew.imaging.tiff;
