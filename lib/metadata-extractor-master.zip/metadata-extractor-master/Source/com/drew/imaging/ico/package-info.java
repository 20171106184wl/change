/**
 * Contains classes for working with ICO (Windows Icon) files.
 */
package com.drew.imaging.ico;
